from django.db import models


class Student(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"


class Grade(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    subject = models.CharField(max_length=100)
    score = models.IntegerField(default=0, help_text="Enter a score between 2 and 5")

    @property
    def average_score(self):
        return Grade.objects.filter(student=self.student).aggregate(models.Avg('score'))['score__avg']
