from django.shortcuts import render
from .models import Student, Grade


def student_list(request):
    students = Student.objects.all()
    return render(request, 'student_list.html', {'students': students})


def student_detail(request, student_id):
    student = Student.objects.get(id=student_id)
    grades = Grade.objects.filter(student=student)
    return render(request, 'student_detail.html', {'student': student, 'grades': grades})
